"""
Optimize Directional Accuracy | 优化方向准确率
Current: 51.59% | 当前: 51.59%
Target: > 55% | 目标: > 55%
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import accuracy_score
import warnings
warnings.filterwarnings('ignore')

def resolve_column(df, name):
    df_cols_lower = {c.lower(): c for c in df.columns}
    return df_cols_lower.get(name.lower())

print("=" * 80)
print("Directional Accuracy Optimization Strategies | 方向准确率优化策略")
print("=" * 80)

# Load data
file_path = r'D:\user\document\qiuzhi py\train.parquet'
df = pd.read_parquet(file_path)

REQUIRED_FEATURES = [
    "X863","X856","X344","X598","X862","X385","X852","X603",
    "X860","X674","X415","X345","X137","X855","X174","X302",
    "X178","X532","X168","X612",
    "bid_qty","ask_qty","buy_qty","sell_qty","volume"
]

resolved_features = []
for col in REQUIRED_FEATURES:
    real = resolve_column(df, col)
    if real is not None:
        resolved_features.append(real)

label_col = resolve_column(df, 'label') or resolve_column(df, 'target_label')
used_cols = resolved_features + [label_col]
data = df[used_cols].copy()
data = data.dropna(subset=[label_col])

for c in resolved_features:
    if data[c].dtype.kind in 'biufc':
        data[c] = data[c].fillna(data[c].median())
    else:
        mode_val = data[c].mode(dropna=True)
        data[c] = data[c].fillna(mode_val.iloc[0] if not mode_val.empty else 0)

X = data[resolved_features].values
y = data[label_col].values

# 80/20 split
split_idx = int(len(data) * 0.8)
X_train, X_test = X[:split_idx], X[split_idx:]
y_train, y_test = y[:split_idx], y[split_idx:]

# Determine task type
y_unique = pd.Series(y).nunique(dropna=True)
is_classification = y_unique <= 20 and (pd.api.types.is_integer_dtype(y) or 
                                       pd.api.types.is_object_dtype(y) or 
                                       pd.api.types.is_bool_dtype(y))

if not is_classification:
    print("\n[Optimization Strategy 1] Target Engineering: Focus on Direction")
    print("=" * 80)
    print("Instead of predicting the exact value, predict the direction (UP/DOWN)")
    print("Instead of predicting exact value, predict direction (UP/DOWN) | 不预测精确值，预测方向")
    
    # Create direction target
    y_train_direction = np.sign(y_train[1:] - y_train[:-1])
    y_test_direction = np.sign(y_test[1:] - y_test[:-1])
    X_train_dir = X_train[:-1]
    X_test_dir = X_test[:-1]
    
    print(f"Original task: Regression (predict exact value)")
    print(f"New task: Classification (predict UP/DOWN)")
    print(f"Training samples: {len(X_train_dir)}, Test samples: {len(X_test_dir)}")
    
    # Train direction classifier
    print("\nTraining Random Forest Classifier for direction prediction...")
    model_dir = RandomForestClassifier(
        n_estimators=500,  # More trees
        max_depth=15,      # Deeper trees
        min_samples_split=10,
        min_samples_leaf=4,
        random_state=42,
        n_jobs=-1,
        class_weight='balanced'  # Handle imbalanced classes
    )
    model_dir.fit(X_train_dir, y_train_direction)
    
    y_pred_dir = model_dir.predict(X_test_dir)
    dir_acc = (y_test_direction == y_pred_dir).mean() * 100
    
    print(f"\nDirectional Accuracy: {dir_acc:.2f}%")
    print(f"Directional Accuracy | 方向准确率: {dir_acc:.2f}%")
    
    if dir_acc >= 55:
        print("✓ Excellent! Model shows strong directional prediction ability | 模型方向预测能力很强")
    elif dir_acc >= 53:
        print("✓ Good! Model has profit potential | 模型有盈利潜力")
    elif dir_acc >= 51:
        print("○ Acceptable, slightly better than random | 可接受，略优于随机")
    else:
        print("✗ Poor, model effectiveness questionable | 较差，模型有效性存疑")

print("\n" + "=" * 80)
print("[Optimization Strategy 2] Feature Engineering: Add Technical Indicators")
print("=" * 80)

# Add moving averages and momentum indicators
print("Adding technical indicators...")
print("1. Moving Averages (MA5, MA10, MA20)")
print("2. Price Momentum (rate of change)")
print("3. Volatility (rolling std)")

# Check if we have time-based features
time_col = None
if 'timestamp' in df.columns:
    time_col = 'timestamp'
elif 'time' in df.columns:
    time_col = 'time'
elif 'date' in df.columns:
    time_col = 'date'

if time_col:
    print(f"Found time column: {time_col}")
    data_sorted = df.sort_values(by=time_col)
    y_sorted = data_sorted[label_col].values
    
    # Calculate technical indicators
    ma5 = pd.Series(y_sorted).rolling(window=5).mean().values
    ma10 = pd.Series(y_sorted).rolling(window=10).mean().values
    ma20 = pd.Series(y_sorted).rolling(window=20).mean().values
    momentum = np.diff(y_sorted, prepend=y_sorted[0])
    volatility = pd.Series(y_sorted).rolling(window=10).std().values
    
    # Add to features
    X_enhanced = np.column_stack([
        X, 
        ma5[:len(X)], 
        ma10[:len(X)], 
        ma20[:len(X)],
        momentum[:len(X)],
        volatility[:len(X)]
    ])
    
    print(f"Original features: {X.shape[1]}")
    print(f"Enhanced features: {X_enhanced.shape[1]}")
    print("Added features: MA5, MA10, MA20, Momentum, Volatility")
else:
    print("No time column found, skipping time-based indicators")
    X_enhanced = X

print("\n" + "=" * 80)
print("[Optimization Strategy 3] Model Ensemble: Combine Multiple Models")
print("=" * 80)
print("Using ensemble of different models can improve robustness")
print("使用多个模型的集成可以提高鲁棒性")

if not is_classification:
    # Train multiple models and ensemble
    from sklearn.ensemble import GradientBoostingRegressor, ExtraTreesRegressor
    
    models = {
        'RandomForest': RandomForestRegressor(n_estimators=300, random_state=42, n_jobs=-1),
        'GradientBoosting': GradientBoostingRegressor(n_estimators=100, random_state=42),
        'ExtraTrees': ExtraTreesRegressor(n_estimators=300, random_state=42, n_jobs=-1)
    }
    
    predictions = []
    
    for name, model in models.items():
        print(f"Training {name}...")
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        predictions.append(pred)
    
    # Ensemble: weighted average
    weights = [0.4, 0.3, 0.3]  # Give more weight to RandomForest
    y_pred_ensemble = np.average(predictions, axis=0, weights=weights)
    
    # Calculate directional accuracy
    true_dirs = np.sign(y_test[1:] - y_test[:-1])
    pred_dirs = np.sign(y_pred_ensemble[1:] - y_test[:-1])
    dir_acc_ensemble = (true_dirs == pred_dirs).mean() * 100
    
    print(f"\nEnsemble Directional Accuracy: {dir_acc_ensemble:.2f}%")
    print(f"Ensemble Directional Accuracy | 集成模型方向准确率: {dir_acc_ensemble:.2f}%")

print("\n" + "=" * 80)
print("[Optimization Strategy 4] Hyperparameter Tuning")
print("=" * 80)
print("Use Optuna or GridSearch to find optimal parameters")
print("使用 Optuna 或 GridSearch 寻找最优参数")

if not is_classification:
    print("\nSuggested hyperparameter ranges:")
    print("- n_estimators: [100, 300, 500]")
    print("- max_depth: [10, 15, 20]")
    print("- min_samples_split: [5, 10, 15]")
    print("- min_samples_leaf: [2, 4, 8]")
    print("- max_features: ['sqrt', 'log2']")

print("\n" + "=" * 80)
print("[Optimization Strategy 5] Data Preprocessing")
print("=" * 80)
print("1. Feature Scaling: Use StandardScaler or MinMaxScaler")
print("2. Feature Selection: Remove low-importance features")
print("3. Remove outliers: Filter extreme values")
print("4. Increase training data: Use more historical data")

print("\n[Summary] Key Recommendations | 总结：关键建议")
print("=" * 80)
print("1. ✓ Focus on direction prediction rather than exact values")
print("   Focus on direction prediction rather than exact values | 专注于方向预测而非精确值")
print("2. ✓ Add technical indicators (MA, momentum, volatility)")
print("   Add technical indicators (MA, momentum, volatility) | 添加技术指标")
print("3. ✓ Use ensemble models for better robustness")
print("   Use ensemble models for better robustness | 使用集成模型")
print("4. ✓ Tune hyperparameters with cross-validation")
print("   Tune hyperparameters with cross-validation | 交叉验证调参")
print("5. ✓ Collect more training data if possible")
print("   Collect more training data if possible | 收集更多训练数据")

print("\n✓ Optimization strategies completed!")
print("=" * 80)

