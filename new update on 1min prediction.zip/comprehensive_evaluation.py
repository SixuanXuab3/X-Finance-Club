"""
Comprehensive Machine Learning Model Evaluation Report
Comprehensive ML Model Evaluation Report | 综合机器学习模型评估报告

Includes detailed evaluation metrics:
- Price accuracy metrics (MAE, MAPE, RMSE) | 价格准确度指标
- Custom success rate with tolerance thresholds | 自定义容忍阈值成功率  
- Directional accuracy (key profit indicator) | 方向准确率 (核心盈利指标)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    f1_score, mean_absolute_error, mean_squared_error, r2_score
)
import warnings
warnings.filterwarnings('ignore')

# 使用英文显示（避免中文字体问题）
# plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False
sns.set_style("whitegrid")

def resolve_column(df, name):
    """不区分大小写查找列名"""
    df_cols_lower = {c.lower(): c for c in df.columns}
    return df_cols_lower.get(name.lower())

def main():
    print("=" * 80)
    print("Comprehensive ML Model Evaluation Report | 机器学习模型综合评估报告")
    print("Using 80% for training, 20% for testing | 使用前80%数据训练，后20%数据测试")
    print("=" * 80)
    
    # 1. 读取数据
    file_path = r'D:\user\document\qiuzhi py\train.parquet'
    print(f"\n[1] 读取数据: {file_path}")
    df = pd.read_parquet(file_path)
    print(f"    数据形状: {df.shape}")
    
    # 2. 定义特征和目标
    REQUIRED_FEATURES = [
        "X863","X856","X344","X598","X862","X385","X852","X603",
        "X860","X674","X415","X345","X137","X855","X174","X302",
        "X178","X532","X168","X612",
        "bid_qty","ask_qty","buy_qty","sell_qty","volume"
    ]
    
    # 解析列名
    resolved_features = []
    missing_features = []
    for col in REQUIRED_FEATURES:
        real = resolve_column(df, col)
        if real is None:
            missing_features.append(col)
        else:
            resolved_features.append(real)
    
    label_col = resolve_column(df, 'label') or resolve_column(df, 'target_label')
    
    if label_col is None:
        print("❌ 错误: 未找到'label'或'target_label'列")
        return
    
    if missing_features:
        print(f"⚠ 缺失特征: {missing_features}")
    
    print(f"✓ 目标列: {label_col}")
    print(f"✓ 使用特征: {len(resolved_features)} 个")
    
    # 3. 准备数据
    used_cols = resolved_features + [label_col]
    data = df[used_cols].copy()
    
    before_rows = len(data)
    data = data.dropna(subset=[label_col])
    print(f"✓ 删除缺失标签后: {len(data)} / {before_rows} 行")
    
    # 填充缺失值
    for c in resolved_features:
        if data[c].dtype.kind in 'biufc':
            data[c] = data[c].fillna(data[c].median())
        else:
            mode_val = data[c].mode(dropna=True)
            data[c] = data[c].fillna(mode_val.iloc[0] if not mode_val.empty else 0)
    
    X = data[resolved_features].values
    y = data[label_col].values
    
    # 判断任务类型
    y_unique = pd.Series(y).nunique(dropna=True)
    is_classification = y_unique <= 20 and (pd.api.types.is_integer_dtype(y) or 
                                           pd.api.types.is_object_dtype(y) or 
                                           pd.api.types.is_bool_dtype(y))
    if not is_classification and y_unique <= 10:
        is_classification = True
    
    # 4. 80/20 数据分割
    print(f"\n[2] 数据分割 (80%训练 / 20%测试)")
    n = len(data)
    split_idx = int(n * 0.8)
    X_train, X_test = X[:split_idx], X[split_idx:]
    y_train, y_test = y[:split_idx], y[split_idx:]
    
    print(f"    总样本数: {n:,}")
    print(f"    训练集: {len(X_train):,} ({100.0*len(X_train)/n:.1f}%)")
    print(f"    测试集: {len(X_test):,} ({100.0*len(X_test)/n:.1f}%)")
    print(f"    任务类型: {'分类' if is_classification else '回归'}")
    
    # 5. 训练模型
    print(f"\n[3] 训练模型...")
    if is_classification:
        model = RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1)
    else:
        model = RandomForestRegressor(n_estimators=200, random_state=42, n_jobs=-1)
    model.fit(X_train, y_train)
    print("✓ 模型训练完成")
    
    # 6. 预测
    y_pred = model.predict(X_test)
    
    # 7. 基础评估
    print(f"\n" + "=" * 80)
    print("[4] 基础评估指标")
    print("=" * 80)
    
    if is_classification:
        acc = accuracy_score(y_test, y_pred)
        macro_f1 = f1_score(y_test, y_pred, average='macro')
        weighted_f1 = f1_score(y_test, y_pred, average='weighted')
        
        print(f"\n分类指标:")
        print(f"  - 准确率 (Accuracy): {acc:.4f} ({acc*100:.2f}%)")
        print(f"  - 宏平均 F1: {macro_f1:.4f}")
        print(f"  - 加权平均 F1: {weighted_f1:.4f}")
        
        # 混淆矩阵
        print(f"\n混淆矩阵:")
        print(confusion_matrix(y_test, y_pred))
        
    else:
        mae = mean_absolute_error(y_test, y_pred)
        mse = mean_squared_error(y_test, y_pred)
        rmse = np.sqrt(mse)
        r2 = r2_score(y_test, y_pred)
        
        print(f"\n回归指标:")
        print(f"  - MAE: {mae:.6f}")
        print(f"  - MSE: {mse:.6f}")
        print(f"  - RMSE: {rmse:.6f}")
        print(f"  - R²: {r2:.4f}")
    
    # 8. 详细成功率评估 (仅回归任务)
    if not is_classification:
        print(f"\n" + "=" * 80)
        print("[5] A. 价格准确度评估")
        print("=" * 80)
        
        residuals = y_test - y_pred
        abs_errors = np.abs(residuals)
        rel_errors = np.abs(residuals) / (np.abs(y_test) + 1e-8) * 100
        
        # MAE
        mae_calc = abs_errors.mean()
        print(f"\n1. MAE (平均绝对误差): {mae_calc:.6f}")
        print(f"   含义: 模型平均预测误差为 {mae_calc:.6f}")
        print(f"   评价: 最直观的误差指标")
        
        # MAPE
        mape = rel_errors.mean()
        print(f"\n2. MAPE (平均绝对百分比误差): {mape:.4f}%")
        print(f"   含义: 模型平均预测误差为 {mape:.4f}%")
        print(f"   评价: 剔除价格本身影响，更公平的指标")
        
        # RMSE
        rmse_calc = np.sqrt((residuals ** 2).mean())
        print(f"\n3. RMSE (均方根误差): {rmse_calc:.6f}")
        print(f"   含义: 对\"大错误\"惩罚更重")
        print(f"   评价: 金融领域更重视此指标")
        
        # 创建结果DataFrame
        results_df = pd.DataFrame({
            'y_true': y_test,
            'y_pred': y_pred,
            'error': residuals,
            'abs_error': abs_errors,
            'rel_error_%': rel_errors
        })
        
        print(f"\n前20个预测结果示例:")
        print(results_df.head(20))
        
        # B. 容忍阈值成功率
        print(f"\n" + "=" * 80)
        print("[6] B. 自定义成功率评估 (容忍阈值)")
        print("=" * 80)
        
        thresholds = [0.1, 0.5, 1.0, 2.0, 5.0]
        
        for threshold in thresholds:
            is_success = (abs_errors <= threshold).astype(int)
            success_rate = is_success.mean() * 100
            count = is_success.sum()
            total = len(is_success)
            
            print(f"\n容忍阈值 ±{threshold}:")
            print(f"  成功率: {success_rate:.2f}% ({count}/{total})")
            print(f"  含义: {success_rate:.2f}%的预测误差在 ±{threshold} 以内")
        
        # C. 方向成功率
        print(f"\n" + "=" * 80)
        print("[7] C. 方向成功率评估 (Directional Accuracy)")
        print("=" * 80)
        print("   这是衡量模型盈利能力的核心指标")
        
        if len(y_test) > 1:
            # 计算真实方向和预测方向
            true_directions = np.sign(y_test[1:] - y_test[:-1])
            pred_directions = np.sign(y_pred[1:] - y_test[:-1])
            
            # 方向准确率
            directional_accuracy = (true_directions == pred_directions).mean() * 100
            correct_count = (true_directions == pred_directions).sum()
            total_count = len(true_directions)
            
            print(f"\n方向预测成功率: {directional_accuracy:.2f}%")
            print(f"正确次数: {correct_count}/{total_count}")
            
            print(f"\n评价:")
            if directional_accuracy >= 55:
                print(f"  ✓ 优秀: 超过55%，模型方向预测能力很强，有显著盈利潜力")
            elif directional_accuracy >= 53:
                print(f"  ✓ 良好: 超过53%，模型有盈利潜力")
            elif directional_accuracy >= 51:
                print(f"  ○ 一般: 超过50%，略优于随机猜测")
            else:
                print(f"  ✗ 较差: 低于51%，模型有效性存疑")
            
            # 显示方向预测详情
            direction_df = pd.DataFrame({
                'true_direction': ['UP' if d > 0 else 'DOWN' for d in true_directions],
                'pred_direction': ['UP' if d > 0 else 'DOWN' for d in pred_directions],
                'correct': true_directions == pred_directions
            })
            
            print(f"\n前20个样本的方向预测:")
            print(direction_df.head(20))
            
            print(f"\n方向预测统计:")
            print(direction_df.groupby('true_direction')['correct'].agg(['count', 'sum', 'mean']))
    
    # 9. 可视化
    print(f"\n" + "=" * 80)
    print("[8] 生成可视化图表...")
    print("=" * 80)
    
    if is_classification:
        # 分类任务可视化
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        
        # 混淆矩阵
        cm = confusion_matrix(y_test, y_pred)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[0])
        axes[0].set_title('Confusion Matrix', fontsize=14, fontweight='bold')
        axes[0].set_xlabel('Predicted')
        axes[0].set_ylabel('True')
        
        # 特征重要性
        if hasattr(model, 'feature_importances_'):
            importances = model.feature_importances_
            imp_df = pd.DataFrame({
                'feature': resolved_features,
                'importance': importances
            }).sort_values('importance', ascending=False)
            
            top_imp = imp_df.head(15).iloc[::-1]
            axes[1].barh(top_imp['feature'], top_imp['importance'], color='#4c78a8')
            axes[1].set_title('Top 15 Feature Importances', fontsize=14, fontweight='bold')
            axes[1].set_xlabel('Importance')
        
        plt.tight_layout()
        save_path = r'D:\user\document\qiuzhi py\classification_results.png'
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"✓ 图表已保存: {save_path}")
        
    else:
        # 回归任务可视化
        fig = plt.figure(figsize=(16, 10))
        residuals = y_test - y_pred
        abs_errors = np.abs(residuals)
        rel_errors = np.abs(residuals) / (np.abs(y_test) + 1e-8) * 100
        
        # 1. True vs Predicted
        ax1 = plt.subplot(2, 3, 1)
        ax1.scatter(y_test, y_pred, alpha=0.5, s=15)
        min_v = np.min([np.min(y_test), np.min(y_pred)])
        max_v = np.max([np.max(y_test), np.max(y_pred)])
        ax1.plot([min_v, max_v], [min_v, max_v], 'r--', lw=2, label='Perfect Line')
        ax1.set_xlabel('True Value')
        ax1.set_ylabel('Predicted Value')
        ax1.set_title('True vs Predicted', fontsize=12, fontweight='bold')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 2. 残差分布
        ax2 = plt.subplot(2, 3, 2)
        ax2.hist(residuals, bins=50, edgecolor='black', alpha=0.7)
        ax2.set_xlabel('Residual (y_true - y_pred)')
        ax2.set_ylabel('Frequency')
        ax2.set_title('Residual Distribution', fontsize=12, fontweight='bold')
        ax2.grid(True, alpha=0.3)
        
        # 3. 绝对误差分布
        ax3 = plt.subplot(2, 3, 3)
        ax3.hist(abs_errors, bins=50, edgecolor='black', alpha=0.7, color='orange')
        ax3.set_xlabel('Absolute Error')
        ax3.set_ylabel('Frequency')
        ax3.set_title('Absolute Error Distribution', fontsize=12, fontweight='bold')
        ax3.grid(True, alpha=0.3)
        
        # 4. 相对误差分布
        ax4 = plt.subplot(2, 3, 4)
        ax4.hist(rel_errors, bins=50, edgecolor='black', alpha=0.7, color='green')
        ax4.set_xlabel('Relative Error (%)')
        ax4.set_ylabel('Frequency')
        ax4.set_title('Relative Error Distribution (%)', fontsize=12, fontweight='bold')
        ax4.grid(True, alpha=0.3)
        
        # 5. 时间序列对比
        ax5 = plt.subplot(2, 3, 5)
        sample_size = min(100, len(y_test))
        x_range = range(sample_size)
        ax5.plot(x_range, y_test[:sample_size], label='True', alpha=0.7, linewidth=1.5)
        ax5.plot(x_range, y_pred[:sample_size], label='Predicted', alpha=0.7, linewidth=1.5)
        ax5.set_xlabel('Sample Index')
        ax5.set_ylabel('Value')
        ax5.set_title('Time Series Comparison (First 100 Samples)', fontsize=12, fontweight='bold')
        ax5.legend()
        ax5.grid(True, alpha=0.3)
        
        # 6. 成功率 vs 容忍阈值
        ax6 = plt.subplot(2, 3, 6)
        thresholds = np.linspace(0, abs_errors.max(), 50)
        success_rates = [(abs_errors <= t).mean() * 100 for t in thresholds]
        ax6.plot(thresholds, success_rates, linewidth=2, color='purple')
        ax6.set_xlabel('Tolerance Threshold')
        ax6.set_ylabel('Success Rate (%)')
        ax6.set_title('Success Rate vs Tolerance Threshold', fontsize=12, fontweight='bold')
        ax6.grid(True, alpha=0.3)
        ax6.axhline(y=50, color='r', linestyle='--', alpha=0.5, label='50% Baseline')
        ax6.axhline(y=90, color='g', linestyle='--', alpha=0.5, label='90% Target')
        ax6.legend()
        
        plt.tight_layout()
        save_path = r'D:\user\document\qiuzhi py\regression_results.png'
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"✓ 图表已保存: {save_path}")
        
        # 方向准确率可视化
        if len(y_test) > 1:
            true_dirs = np.sign(y_test[1:] - y_test[:-1])
            pred_dirs = np.sign(y_pred[1:] - y_test[:-1])
            
            fig_dir, axes_dir = plt.subplots(1, 2, figsize=(12, 5))
            
            # 方向预测准确率条形图
            direction_df_viz = pd.DataFrame({
                'true_direction': ['UP' if d > 0 else 'DOWN' for d in true_dirs],
                'pred_direction': ['UP' if d > 0 else 'DOWN' for d in pred_dirs],
                'correct': true_dirs == pred_dirs
            })
            
            dir_acc_by_true = direction_df_viz.groupby('true_direction')['correct'].mean() * 100
            axes_dir[0].bar(dir_acc_by_true.index, dir_acc_by_true.values, color=['green', 'red'])
            axes_dir[0].set_ylabel('Directional Accuracy (%)')
            axes_dir[0].set_title('Directional Accuracy (by True Direction)', fontsize=12, fontweight='bold')
            axes_dir[0].grid(True, alpha=0.3)
            axes_dir[0].axhline(y=50, color='black', linestyle='--', alpha=0.3)
            
            # 方向预测统计
            dir_counts = direction_df_viz['true_direction'].value_counts()
            axes_dir[1].bar(dir_counts.index, dir_counts.values, color=['green', 'red'], alpha=0.5)
            axes_dir[1].set_ylabel('Sample Count')
            axes_dir[1].set_title('True Direction Distribution', fontsize=12, fontweight='bold')
            axes_dir[1].grid(True, alpha=0.3)
            
            plt.tight_layout()
            save_path_dir = r'D:\user\document\qiuzhi py\directional_accuracy.png'
            plt.savefig(save_path_dir, dpi=150, bbox_inches='tight')
            print(f"✓ 方向准确率图表已保存: {save_path_dir}")
    
    # 10. 特征重要性
    if hasattr(model, 'feature_importances_'):
        importances = model.feature_importances_
        imp_df = pd.DataFrame({
            'feature': resolved_features,
            'importance': importances
        }).sort_values('importance', ascending=False)
        
        plt.figure(figsize=(10, 8))
        top_imp = imp_df.head(20).iloc[::-1]
        plt.barh(top_imp['feature'], top_imp['importance'], color='#4c78a8')
        plt.xlabel('Importance')
        plt.title('Top 20 Feature Importances (RandomForest)', fontsize=14, fontweight='bold')
        plt.tight_layout()
        save_path_imp = r'D:\user\document\qiuzhi py\feature_importance.png'
        plt.savefig(save_path_imp, dpi=150, bbox_inches='tight')
        print(f"✓ 特征重要性图表已保存: {save_path_imp}")
        
        print(f"\nTop 10 最重要特征:")
        print(imp_df.head(10).to_string(index=False))
    
    # 11. 最终总结
    print(f"\n" + "=" * 80)
    print("[9] 最终评估总结")
    print("=" * 80)
    
    print(f"\n数据信息:")
    print(f"  - 总样本数: {n:,}")
    print(f"  - 训练集: {len(X_train):,} ({100.0*len(X_train)/n:.1f}%)")
    print(f"  - 测试集: {len(X_test):,} ({100.0*len(X_test)/n:.1f}%)")
    print(f"  - 特征数量: {len(resolved_features)}")
    print(f"  - 任务类型: {'分类' if is_classification else '回归'}")
    
    if is_classification:
        print(f"\n分类性能:")
        print(f"  - 准确率: {accuracy_score(y_test, y_pred):.4f} ({accuracy_score(y_test, y_pred)*100:.2f}%)")
        print(f"  - 宏平均F1: {f1_score(y_test, y_pred, average='macro'):.4f}")
        print(f"  - 加权F1: {f1_score(y_test, y_pred, average='weighted'):.4f}")
    else:
        print(f"\n回归性能:")
        print(f"  - MAE: {mean_absolute_error(y_test, y_pred):.6f}")
        rel_errors_final = np.abs(y_test - y_pred) / (np.abs(y_test) + 1e-8) * 100
        print(f"  - MAPE: {rel_errors_final.mean():.4f}%")
        print(f"  - RMSE: {np.sqrt(mean_squared_error(y_test, y_pred)):.6f}")
        print(f"  - R²: {r2_score(y_test, y_pred):.4f}")
        
        if len(y_test) > 1:
            true_dirs_final = np.sign(y_test[1:] - y_test[:-1])
            pred_dirs_final = np.sign(y_pred[1:] - y_test[:-1])
            dir_acc_final = (true_dirs_final == pred_dirs_final).mean() * 100
            print(f"  - 方向准确率: {dir_acc_final:.2f}%")
    
    print(f"\n✓ 评估完成！")
    print(f"所有图表已保存到: D:\\user\\document\\qiuzhi py\\")

if __name__ == "__main__":
    main()

